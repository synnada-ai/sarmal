def first_function_sarmal():
    print("first function of composite ML library sarmal")